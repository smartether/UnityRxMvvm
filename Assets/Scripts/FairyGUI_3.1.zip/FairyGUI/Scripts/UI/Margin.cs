﻿
namespace FairyGUI
{
	/// <summary>
	/// 
	/// </summary>
	public struct Margin
	{
		/// <summary>
		/// 
		/// </summary>
		public int left;
		
		/// <summary>
		/// 
		/// </summary>
		public int right;

		/// <summary>
		/// 
		/// </summary>
		public int top;

		/// <summary>
		/// 
		/// </summary>
		public int bottom;
	}
}
